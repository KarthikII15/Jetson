// src/trt_engine.cpp
#include "trt_engine.hpp"
#include <NvOnnxParser.h>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <spdlog/spdlog.h>

// ── Logger ────────────────────────────────────────────────────────────────────
void TRTLogger::log(Severity sev, const char* msg) noexcept {
    switch (sev) {
        case Severity::kERROR:   spdlog::error("[TRT] {}", msg); break;
        case Severity::kWARNING: spdlog::warn("[TRT] {}",  msg); break;
        case Severity::kINFO:    spdlog::debug("[TRT] {}", msg); break;
        default: break;
    }
}

// ── CudaBuffer ────────────────────────────────────────────────────────────────
CudaBuffer::CudaBuffer(size_t bytes) : size(bytes) {
    if (cudaMalloc(&dev, bytes) != cudaSuccess)
        throw std::runtime_error("cudaMalloc failed for " + std::to_string(bytes) + " bytes");
}

CudaBuffer::~CudaBuffer() {
    if (dev) cudaFree(dev);
}

CudaBuffer::CudaBuffer(CudaBuffer&& o) noexcept : dev(o.dev), size(o.size) {
    o.dev = nullptr; o.size = 0;
}

CudaBuffer& CudaBuffer::operator=(CudaBuffer&& o) noexcept {
    if (dev) cudaFree(dev);
    dev = o.dev; size = o.size;
    o.dev = nullptr; o.size = 0;
    return *this;
}

// ── Engine ────────────────────────────────────────────────────────────────────
TRTEngine::TRTEngine(const std::string& engine_path) {
    // Read serialized engine
    std::ifstream f(engine_path, std::ios::binary | std::ios::ate);
    if (!f.good())
        throw std::runtime_error("Cannot open engine: " + engine_path);

    auto size = f.tellg();
    f.seekg(0);
    std::vector<char> buf(size);
    f.read(buf.data(), size);

    runtime_.reset(nvinfer1::createInferRuntime(logger_));
    if (!runtime_)
        throw std::runtime_error("createInferRuntime failed");

    engine_.reset(runtime_->deserializeCudaEngine(buf.data(), buf.size()));
    if (!engine_)
        throw std::runtime_error("deserializeCudaEngine failed for: " + engine_path);

    ctx_.reset(engine_->createExecutionContext());
    if (!ctx_)
        throw std::runtime_error("createExecutionContext failed");

    allocateBuffers();
    spdlog::info("[TRT] Engine loaded: {} ({} bindings)", engine_path, numBindings());
}

void TRTEngine::allocateBuffers() {
    int n = numBindings();
    dev_bufs_.clear();
    dev_bufs_.reserve(n);
    for (int i = 0; i < n; ++i) {
        dev_bufs_.emplace_back(bindingSize(i));
    }
}

bool TRTEngine::infer(const std::vector<const float*>& inputs,
                      const std::vector<float*>&       outputs,
                      cudaStream_t stream) {
    // Copy inputs host→device
    int in_idx  = 0;
    int out_idx = 0;
    std::vector<void*> bindings(numBindings());

    for (int i = 0; i < numBindings(); ++i) {
        bindings[i] = dev_bufs_[i].dev;
        if (isInput(i)) {
            cudaMemcpyAsync(dev_bufs_[i].dev, inputs[in_idx],
                            dev_bufs_[i].size, cudaMemcpyHostToDevice, stream);
            ++in_idx;
        }
    }

    // Execute
    bool ok = ctx_->executeV2(bindings.data());

    // Copy outputs device→host
    for (int i = 0; i < numBindings(); ++i) {
        if (!isInput(i)) {
            cudaMemcpyAsync(outputs[out_idx], dev_bufs_[i].dev,
                            dev_bufs_[i].size, cudaMemcpyDeviceToHost, stream);
            ++out_idx;
        }
    }

    if (stream) cudaStreamSynchronize(stream);
    return ok;
}

int TRTEngine::numBindings() const {
    return engine_->getNbBindings();
}

bool TRTEngine::isInput(int idx) const {
    return engine_->bindingIsInput(idx);
}

std::vector<int> TRTEngine::inputDims(int idx) const {
    auto dims = engine_->getBindingDimensions(idx);
    return std::vector<int>(dims.d, dims.d + dims.nbDims);
}

std::vector<int> TRTEngine::outputDims(int idx) const {
    return inputDims(idx);
}

size_t TRTEngine::bindingSize(int idx) const {
    auto dims = engine_->getBindingDimensions(idx);
    size_t n = 1;
    for (int d = 0; d < dims.nbDims; ++d) n *= std::max(1, dims.d[d]);
    // dtype — assume float32 for all
    return n * sizeof(float);
}

int TRTEngine::maxBatchSize() const {
    return engine_->getMaxBatchSize();
}
