// src/runner.cpp
#include "runner.hpp"
#include <spdlog/spdlog.h>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

// ── Constructor ───────────────────────────────────────────────────────────────
FRSRunner::FRSRunner(const Config& cfg, const std::vector<CameraConfig>& cameras)
    : cfg_(cfg), cameras_(cameras)
{
    detector_ = std::make_unique<FaceDetector>(cfg_.det_engine,
                                                cfg_.conf_thresh,
                                                cfg_.nms_thresh);
    embedder_ = std::make_unique<FaceEmbedder>(cfg_.emb_engine);
    http_     = std::make_unique<HttpClient>(cfg_.backend_url, cfg_.token_path);

    spdlog::info("[Runner] Initialized with {} camera(s)", cameras_.size());
}

FRSRunner::~FRSRunner() { stop(); }

// ── Lifecycle ─────────────────────────────────────────────────────────────────
void FRSRunner::start() {
    running_.store(true);

    // Start inference worker threads (share detector+embedder — TRT is thread-safe for infer)
    for (int i = 0; i < cfg_.inference_threads; ++i) {
        workers_.emplace_back([this]{ inferenceWorker(); });
        spdlog::info("[Runner] Inference worker {} started", i);
    }

    // Start one capture thread per camera
    for (const auto& cam : cameras_) {
        auto cap = std::make_unique<CaptureThread>(cam,
            [this](const std::string& id, const std::string& code, cv::Mat f){
                enqueueFrame(id, code, std::move(f));
            });
        cap->start();
        captures_.push_back(std::move(cap));
    }

    spdlog::info("[Runner] All threads started — FRS is live");
}

void FRSRunner::stop() {
    running_.store(false);
    queue_cv_.notify_all();

    for (auto& cap : captures_) cap->stop();
    captures_.clear();

    for (auto& w : workers_) if (w.joinable()) w.join();
    workers_.clear();

    spdlog::info("[Runner] Stopped");
}

// ── Frame queue ───────────────────────────────────────────────────────────────
void FRSRunner::enqueueFrame(const std::string& cam_id,
                               const std::string& dev_code,
                               cv::Mat frame) {
    std::unique_lock<std::mutex> lock(queue_mtx_);
    if ((int)queue_.size() >= cfg_.queue_depth) {
        // Drop oldest frame under load — attendance latency is acceptable
        queue_.pop();
    }
    queue_.push({cam_id, dev_code, std::move(frame)});
    queue_cv_.notify_one();
}

// ── Cooldown cache ────────────────────────────────────────────────────────────
bool FRSRunner::checkCooldown(const std::string& cam_id) {
    using namespace std::chrono;
    auto now = duration_cast<duration<double>>(
        steady_clock::now().time_since_epoch()).count();

    std::lock_guard<std::mutex> lock(cooldown_mtx_);
    auto it = last_sent_.find(cam_id);
    if (it != last_sent_.end() && (now - it->second) < cfg_.cooldown_sec)
        return false;  // still in cooldown

    last_sent_[cam_id] = now;
    return true;
}

// ── ISO8601 timestamp ─────────────────────────────────────────────────────────
std::string FRSRunner::nowIso8601() {
    auto now  = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    auto ms   = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count() % 1000;

    std::ostringstream ss;
    ss << std::put_time(std::gmtime(&time), "%Y-%m-%dT%H:%M:%S")
       << "." << std::setfill('0') << std::setw(3) << ms << "Z";
    return ss.str();
}

// ── Main inference worker ─────────────────────────────────────────────────────
void FRSRunner::inferenceWorker() {
    while (running_.load()) {
        FrameTask task;
        {
            std::unique_lock<std::mutex> lock(queue_mtx_);
            queue_cv_.wait(lock, [this]{
                return !queue_.empty() || !running_.load();
            });
            if (!running_.load() && queue_.empty()) break;
            task = std::move(queue_.front());
            queue_.pop();
        }

        stat_frames_.fetch_add(1);

        // ── Step 1: Face detection (YOLOv8 TRT) ──────────────────────────────
        auto faces = detector_->detect(task.frame);
        if (faces.empty()) continue;

        stat_faces_.fetch_add(faces.size());

        // ── Step 2: Cooldown check (per camera) ──────────────────────────────
        // Check before embedding to save GPU time
        if (!checkCooldown(task.cam_id)) continue;

        // ── Step 3: Embedding (ArcFace TRT) — top face only ──────────────────
        const auto& top_face = faces[0];  // highest confidence
        auto embedding = embedder_->embed(top_face.aligned);

        // ── Step 4: Send to backend for pgvector search ───────────────────────
        RecognitionPayload payload;
        payload.device_id   = task.cam_id;
        payload.device_code = task.device_code;
        payload.confidence  = top_face.conf;
        payload.timestamp   = nowIso8601();
        payload.embedding   = embedding;

        auto result = http_->recognize(payload);

        if (result.matched) {
            stat_matches_.fetch_add(1);
            spdlog::info("[{}] ✅ {} ({}) sim={:.3f}",
                task.cam_id, result.full_name,
                result.employee_code, result.similarity);
        } else if (result.http_code == 404) {
            stat_unknowns_.fetch_add(1);
            spdlog::debug("[{}] ⚠  Unknown face (conf={:.2f})", task.cam_id, top_face.conf);
        } else if (result.http_code == 401) {
            // Token expired — reset cooldown so we retry
            std::lock_guard<std::mutex> lock(cooldown_mtx_);
            last_sent_.erase(task.cam_id);
        }
    }
}

// ── Stats ─────────────────────────────────────────────────────────────────────
FRSRunner::Stats FRSRunner::stats() const {
    std::unique_lock<std::mutex> lock(
        const_cast<std::mutex&>(queue_mtx_));
    return {
        stat_frames_.load(),
        stat_faces_.load(),
        stat_matches_.load(),
        stat_unknowns_.load(),
        (int)queue_.size(),
        (int)captures_.size()
    };
}
