#pragma once
// include/http_client.hpp
// Async HTTP client using libcurl for posting recognition events to Node.js backend

#include <string>
#include <functional>
#include <array>

using Embedding = std::array<float, 512>;

struct RecognitionPayload {
    std::string device_id;    // camera ID
    std::string device_code;  // camera device_code for backend
    float       confidence;   // detection confidence
    std::string timestamp;    // ISO8601 UTC
    Embedding   embedding;    // 512-d L2-normalized
};

struct RecognitionResult {
    bool        matched;
    std::string employee_id;
    std::string full_name;
    std::string employee_code;
    float       similarity;
    int         http_code;
};

class HttpClient {
public:
    explicit HttpClient(const std::string& backend_url, const std::string& token_path);

    // POST /api/face/recognize — blocking, call from dedicated thread
    RecognitionResult recognize(const RecognitionPayload& payload);

    // POST /api/attendance/mark — direct mark without embedding search
    bool markAttendance(const std::string& employee_id,
                         const std::string& device_code,
                         const std::string& timestamp,
                         const std::string& status = "present");

    // Refresh token from file (called before each request)
    void refreshToken();

private:
    std::string backend_url_;
    std::string token_path_;
    std::string token_;

    std::string readToken();
    std::string embeddingToJson(const Embedding& emb);

    // Low-level POST — returns response body and HTTP code
    std::pair<std::string, int> post(const std::string& path,
                                      const std::string& body);
};
