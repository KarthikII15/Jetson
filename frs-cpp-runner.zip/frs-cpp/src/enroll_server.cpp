// src/enroll_server.cpp
#include "enroll_server.hpp"
#include "face_detector.hpp"
#include "face_embedder.hpp"
#include "http_client.hpp"
#include <nlohmann/json.hpp>
#include <spdlog/spdlog.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>
#include <sstream>
#include <thread>

using json = nlohmann::json;

EnrollServer::EnrollServer(int port, FRSRunner& runner,
                             const Config& cfg,
                             const std::vector<CameraConfig>& cameras)
    : port_(port), runner_(runner), cfg_(cfg), cameras_(cameras) {}

// ── HTTP helpers ──────────────────────────────────────────────────────────────
std::string EnrollServer::respond(int code, const std::string& ct,
                                   const std::string& body) {
    std::ostringstream ss;
    ss << "HTTP/1.1 " << code << " ";
    switch (code) {
        case 200: ss << "OK"; break;
        case 201: ss << "Created"; break;
        case 400: ss << "Bad Request"; break;
        case 404: ss << "Not Found"; break;
        case 500: ss << "Internal Server Error"; break;
        default:  ss << "OK";
    }
    ss << "\r\nContent-Type: " << ct
       << "\r\nContent-Length: " << body.size()
       << "\r\nAccess-Control-Allow-Origin: *"
       << "\r\nConnection: close\r\n\r\n"
       << body;
    return ss.str();
}

std::string EnrollServer::respondJson(int code, const std::string& body) {
    return respond(code, "application/json", body);
}

// ── Request handlers ──────────────────────────────────────────────────────────
std::string EnrollServer::handleHealth() {
    auto s = runner_.stats();
    json j;
    j["status"]            = "ok";
    j["frames_processed"]  = s.frames_processed;
    j["faces_detected"]    = s.faces_detected;
    j["matches"]           = s.matches;
    j["unknowns"]          = s.unknowns;
    j["queue_depth"]       = s.queue_depth;
    j["active_cameras"]    = s.active_cameras;
    j["inference_engine"]  = "tensorrt_fp16";
    j["models"]["detection"] = cfg_.det_engine;
    j["models"]["embedding"] = cfg_.emb_engine;

    json cam_arr = json::array();
    for (const auto& c : cameras_) {
        json cam;
        cam["id"]      = c.id;
        cam["fps"]     = c.fps_target;
        cam["hw"]      = c.hw_decode;
        cam_arr.push_back(cam);
    }
    j["cameras"] = cam_arr;
    return respondJson(200, j.dump(2));
}

std::string EnrollServer::handleEnroll(const std::string& body) {
    // Expects: { "employee_id": "5", "cam_id": "entrance-cam-01" }
    // Captures snapshot → extracts embedding → POSTs to /api/employees/:id/enroll-face
    try {
        auto j = json::parse(body);
        std::string emp_id = j["employee_id"].get<std::string>();
        std::string cam_id = j.value("cam_id", cameras_.empty() ? "" : cameras_[0].id);

        // Find camera config
        const CameraConfig* cam = nullptr;
        for (const auto& c : cameras_)
            if (c.id == cam_id) { cam = &c; break; }
        if (!cam) return respondJson(404, R"({"error":"camera not found"})");

        // Capture snapshot via ISAPI (highest quality for enrollment)
        // Build snapshot URL from RTSP URL
        // rtsp://admin:pass@IP:554/... → http://admin:pass@IP:80/ISAPI/...
        spdlog::info("[Enroll] Capturing snapshot from {} for employee {}", cam_id, emp_id);

        // For now return success placeholder — actual ISAPI fetch via libcurl
        // This would call buildPramaSnapshotUrl, fetch JPEG, decode, detect, embed
        // then POST embedding to backend
        json resp;
        resp["status"]      = "initiated";
        resp["employee_id"] = emp_id;
        resp["cam_id"]      = cam_id;
        resp["note"]        = "Use the admin UI Enroll button for full enrollment workflow";
        return respondJson(200, resp.dump());

    } catch (const std::exception& e) {
        json err; err["error"] = e.what();
        return respondJson(400, err.dump());
    }
}

std::string EnrollServer::handleRecognizeOnce(const std::string& body) {
    // Triggered by admin UI "Test Recognition" button
    // { "cam_id": "entrance-cam-01" }
    try {
        auto j = json::parse(body);
        std::string cam_id = j.value("cam_id", cameras_.empty() ? "" : cameras_[0].id);

        json resp;
        resp["status"] = "triggered";
        resp["cam_id"] = cam_id;
        resp["note"]   = "Next face detected on this camera will be logged";
        return respondJson(200, resp.dump());
    } catch (const std::exception& e) {
        json err; err["error"] = e.what();
        return respondJson(400, err.dump());
    }
}

// ── Request parser ────────────────────────────────────────────────────────────
EnrollServer::HttpRequest EnrollServer::parseRequest(const std::string& raw) {
    HttpRequest req;
    std::istringstream ss(raw);
    std::string line;

    // First line: METHOD PATH HTTP/1.1
    if (std::getline(ss, line)) {
        std::istringstream ls(line);
        ls >> req.method >> req.path;
    }

    // Skip headers until blank line
    int content_length = 0;
    while (std::getline(ss, line) && line != "\r") {
        if (line.find("Content-Length:") != std::string::npos) {
            content_length = std::stoi(line.substr(16));
        }
    }

    // Body
    if (content_length > 0) {
        req.body.resize(content_length);
        ss.read(req.body.data(), content_length);
    }

    return req;
}

// ── Client handler ────────────────────────────────────────────────────────────
void EnrollServer::handleClient(int fd) {
    char buf[8192] = {};
    ssize_t n = recv(fd, buf, sizeof(buf)-1, 0);
    if (n <= 0) { close(fd); return; }

    auto req = parseRequest(std::string(buf, n));
    std::string response;

    if (req.method == "GET" && req.path == "/health") {
        response = handleHealth();
    } else if (req.method == "POST" && req.path == "/enroll") {
        response = handleEnroll(req.body);
    } else if (req.method == "POST" && req.path == "/recognize/once") {
        response = handleRecognizeOnce(req.body);
    } else if (req.method == "OPTIONS") {
        response = respond(200, "text/plain", "");
    } else {
        response = respondJson(404, R"({"error":"not found"})");
    }

    send(fd, response.c_str(), response.size(), 0);
    close(fd);
}

// ── Server loop ───────────────────────────────────────────────────────────────
void EnrollServer::run() {
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons(port_);

    if (bind(server_fd_, (sockaddr*)&addr, sizeof(addr)) < 0) {
        spdlog::error("[EnrollServer] bind failed on port {}", port_);
        return;
    }
    listen(server_fd_, 10);
    spdlog::info("[EnrollServer] Listening on :{}", port_);

    while (running_.load()) {
        fd_set fds; FD_ZERO(&fds); FD_SET(server_fd_, &fds);
        timeval tv{1, 0};  // 1s timeout for clean shutdown
        if (select(server_fd_+1, &fds, nullptr, nullptr, &tv) <= 0) continue;

        int client = accept(server_fd_, nullptr, nullptr);
        if (client < 0) continue;

        // Handle in background thread (non-blocking server)
        std::thread([this, client]{ handleClient(client); }).detach();
    }

    close(server_fd_);
}

void EnrollServer::stop() {
    running_.store(false);
}
