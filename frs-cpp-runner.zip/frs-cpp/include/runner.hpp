#pragma once
// include/runner.hpp
// Main FRS runner — manages capture threads, inference pipeline, cooldown cache

#include "gst_capture.hpp"
#include "face_detector.hpp"
#include "face_embedder.hpp"
#include "http_client.hpp"

#include <vector>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <queue>
#include <condition_variable>
#include <thread>
#include <atomic>

struct Config {
    std::string det_engine;       // path to YOLOv8-face .engine
    std::string emb_engine;       // path to ArcFace R50 .engine
    std::string backend_url;      // http://VM_IP:8080
    std::string token_path;       // /opt/frs/device_token.txt
    float       conf_thresh = 0.45f;
    float       nms_thresh  = 0.45f;
    float       match_thresh = 0.55f;  // cosine similarity threshold
    double      cooldown_sec = 10.0;   // min seconds between marks per camera
    int         inference_threads = 2; // parallel TRT inference workers
    int         queue_depth = 64;
};

struct FrameTask {
    std::string cam_id;
    std::string device_code;
    cv::Mat     frame;
};

class FRSRunner {
public:
    FRSRunner(const Config& cfg, const std::vector<CameraConfig>& cameras);
    ~FRSRunner();

    void start();
    void stop();

    // Stats for /health endpoint
    struct Stats {
        uint64_t frames_processed;
        uint64_t faces_detected;
        uint64_t matches;
        uint64_t unknowns;
        int      queue_depth;
        int      active_cameras;
    };
    Stats stats() const;

private:
    Config                               cfg_;
    std::vector<CameraConfig>            cameras_;
    std::vector<std::unique_ptr<CaptureThread>> captures_;

    // Inference pipeline
    std::unique_ptr<FaceDetector>        detector_;
    std::unique_ptr<FaceEmbedder>        embedder_;
    std::unique_ptr<HttpClient>          http_;

    // Frame queue
    std::queue<FrameTask>                queue_;
    std::mutex                           queue_mtx_;
    std::condition_variable              queue_cv_;
    std::atomic<bool>                    running_{false};
    std::vector<std::thread>             workers_;

    // Per-camera cooldown
    std::unordered_map<std::string, double> last_sent_;
    std::mutex                              cooldown_mtx_;

    // Stats
    std::atomic<uint64_t> stat_frames_{0};
    std::atomic<uint64_t> stat_faces_{0};
    std::atomic<uint64_t> stat_matches_{0};
    std::atomic<uint64_t> stat_unknowns_{0};

    void enqueueFrame(const std::string& cam_id, const std::string& dev_code, cv::Mat frame);
    void inferenceWorker();
    bool checkCooldown(const std::string& cam_id);
    std::string nowIso8601();
};
