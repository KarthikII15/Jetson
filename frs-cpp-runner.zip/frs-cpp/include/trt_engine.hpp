#pragma once
// include/trt_engine.hpp — TensorRT engine RAII wrapper
// Handles: load, serialize, deserialize, single/batch inference

#include <NvInfer.h>
#include <cuda_runtime_api.h>
#include <memory>
#include <string>
#include <vector>

// ── TensorRT logger ───────────────────────────────────────────────────────────
class TRTLogger : public nvinfer1::ILogger {
public:
    void log(Severity severity, const char* msg) noexcept override;
};

// ── CUDA buffer helpers ───────────────────────────────────────────────────────
struct CudaBuffer {
    void*  dev  = nullptr;
    size_t size = 0;

    CudaBuffer() = default;
    CudaBuffer(size_t bytes);
    ~CudaBuffer();

    CudaBuffer(const CudaBuffer&) = delete;
    CudaBuffer& operator=(const CudaBuffer&) = delete;
    CudaBuffer(CudaBuffer&& o) noexcept;
    CudaBuffer& operator=(CudaBuffer&&) noexcept;
};

// ── Engine wrapper ────────────────────────────────────────────────────────────
class TRTEngine {
public:
    // Load pre-built .engine file
    explicit TRTEngine(const std::string& engine_path);
    ~TRTEngine() = default;

    // Execute synchronous inference
    // inputs:  host pointers, one per input binding
    // outputs: host pointers, one per output binding
    bool infer(const std::vector<const float*>& inputs,
               const std::vector<float*>&       outputs,
               cudaStream_t stream = nullptr);

    // Binding info
    int  numBindings()            const;
    bool isInput(int idx)         const;
    std::vector<int> inputDims(int idx)  const;
    std::vector<int> outputDims(int idx) const;
    size_t bindingSize(int idx)   const;  // bytes

    // Max batch size from engine
    int maxBatchSize() const;

private:
    TRTLogger                             logger_;
    std::shared_ptr<nvinfer1::IRuntime>   runtime_;
    std::shared_ptr<nvinfer1::ICudaEngine> engine_;
    std::unique_ptr<nvinfer1::IExecutionContext> ctx_;
    std::vector<CudaBuffer>               dev_bufs_;
    cudaStream_t                          own_stream_ = nullptr;

    void allocateBuffers();
};
