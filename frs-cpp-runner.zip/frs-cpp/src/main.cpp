// src/main.cpp
// FRS2 C++ TensorRT runner for Jetson Orin
// Usage: frs_runner --config /opt/frs/config.json

#include "runner.hpp"
#include "enroll_server.hpp"
#include <nlohmann/json.hpp>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <fstream>
#include <csignal>
#include <atomic>
#include <thread>
#include <iostream>

using json = nlohmann::json;

static std::atomic<bool> g_shutdown{false};

void sigHandler(int) { g_shutdown.store(true); }

// ── Config loader ─────────────────────────────────────────────────────────────
Config loadConfig(const std::string& path) {
    std::ifstream f(path);
    if (!f.good()) throw std::runtime_error("Cannot open config: " + path);
    auto j = json::parse(f);

    Config cfg;
    cfg.det_engine       = j["models"]["face_detection"]["engine_path"];
    cfg.emb_engine       = j["models"]["face_embedding"]["engine_path"];
    cfg.backend_url      = j["backend"]["url"];
    cfg.token_path       = j["backend"]["token_path"];
    cfg.conf_thresh      = j.value("conf_threshold",    0.45f);
    cfg.nms_thresh       = j.value("nms_threshold",     0.45f);
    cfg.match_thresh     = j.value("match_threshold",   0.55f);
    cfg.cooldown_sec     = j.value("cooldown_seconds",  10.0);
    cfg.inference_threads = j.value("inference_threads", 2);
    cfg.queue_depth      = j.value("queue_depth",       64);
    return cfg;
}

std::vector<CameraConfig> loadCameras(const std::string& path) {
    std::ifstream f(path);
    if (!f.good()) throw std::runtime_error("Cannot open cameras: " + path);
    auto j = json::parse(f);

    std::vector<CameraConfig> cams;
    for (const auto& c : j["cameras"]) {
        if (!c.value("enabled", true)) continue;
        CameraConfig cam;
        cam.id          = c["id"];
        cam.rtsp_url    = c["rtsp_url"];
        cam.device_code = c.value("device_code", cam.id);
        cam.fps_target  = c.value("fps_target", 5);
        cam.width       = c.value("width",  1280);
        cam.height      = c.value("height",  720);
        cam.hw_decode   = c.value("hw_decode", true);
        cams.push_back(cam);
    }
    return cams;
}

// ── Main ──────────────────────────────────────────────────────────────────────
int main(int argc, char** argv) {
    // ── Logging setup ─────────────────────────────────────────────────────────
    auto rotating = std::make_shared<spdlog::sinks::rotating_file_sink_mt>(
        "/var/log/frs_runner.log", 10 * 1024 * 1024, 3);
    auto logger = std::make_shared<spdlog::logger>("frs", rotating);
    spdlog::set_default_logger(logger);
    spdlog::set_level(spdlog::level::info);
    spdlog::flush_on(spdlog::level::warn);

    // Also log to stdout for systemd journal
    spdlog::set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%l] %v");

    // ── Parse args ────────────────────────────────────────────────────────────
    std::string config_path  = "/opt/frs/config.json";
    std::string cameras_path = "/opt/frs/cameras.json";
    int         sidecar_port = 5000;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--config"  && i+1 < argc) config_path  = argv[++i];
        if (arg == "--cameras" && i+1 < argc) cameras_path = argv[++i];
        if (arg == "--port"    && i+1 < argc) sidecar_port = std::stoi(argv[++i]);
    }

    spdlog::info("FRS2 C++ Runner starting");
    spdlog::info("  Config:  {}", config_path);
    spdlog::info("  Cameras: {}", cameras_path);
    spdlog::info("  Port:    {}", sidecar_port);

    // ── Signal handlers ───────────────────────────────────────────────────────
    std::signal(SIGINT,  sigHandler);
    std::signal(SIGTERM, sigHandler);

    try {
        // ── Load config ───────────────────────────────────────────────────────
        auto cfg     = loadConfig(config_path);
        auto cameras = loadCameras(cameras_path);

        if (cameras.empty()) {
            spdlog::error("No cameras configured — exiting");
            return 1;
        }

        spdlog::info("Loaded {} camera(s)", cameras.size());
        for (const auto& c : cameras)
            spdlog::info("  {} → {}", c.id, c.rtsp_url.substr(0, 30) + "...");

        // ── Start inference runner ────────────────────────────────────────────
        FRSRunner runner(cfg, cameras);
        runner.start();

        // ── Start enrollment HTTP sidecar ─────────────────────────────────────
        // GET  /health          — runner stats
        // POST /enroll          — enroll face from live snapshot
        // POST /recognize/once  — one-shot recognition (for admin UI)
        EnrollServer enroll(sidecar_port, runner, cfg, cameras);
        std::thread enroll_thread([&enroll]{ enroll.run(); });

        spdlog::info("All systems running. PID={}", getpid());

        // ── Main loop — print stats every 30s ─────────────────────────────────
        while (!g_shutdown.load()) {
            std::this_thread::sleep_for(std::chrono::seconds(30));
            auto s = runner.stats();
            spdlog::info("STATS | frames={} faces={} matches={} unknowns={} queue={}/{}",
                s.frames_processed, s.faces_detected,
                s.matches, s.unknowns,
                s.queue_depth, cfg.queue_depth);
        }

        // ── Graceful shutdown ─────────────────────────────────────────────────
        spdlog::info("Shutting down...");
        enroll.stop();
        if (enroll_thread.joinable()) enroll_thread.join();
        runner.stop();

    } catch (const std::exception& e) {
        spdlog::critical("Fatal error: {}", e.what());
        return 1;
    }

    spdlog::info("FRS2 runner stopped cleanly");
    return 0;
}
